unit SerialNGDllUseMain;
{
  Hello folks,
  here is the usage application of the tiny SerialNG Dll
  There are only elementary stuff implemented, e.g. how to call the
  functions from the DLL.
}
interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs,SerialNGDllImport, StdCtrls, ExtCtrls;

type
  TForm1 = class(TForm)
    cbPorts: TComboBox;
    btnOpenPort: TButton;
    btnClosePort: TButton;
    edtSendText: TEdit;
    btnSend: TButton;
    cbAddCRLF: TCheckBox;
    memoTerminal: TMemo;
    Timer1: TTimer;
    procedure Timer1Timer(Sender: TObject);
    procedure btnSendClick(Sender: TObject);
    procedure btnClosePortClick(Sender: TObject);
    procedure btnOpenPortClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private-Deklarationen }
    procedure ReceiveData;
  public
    { Public-Deklarationen }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  cbPorts.ItemIndex := 0;
  if InitDLL <> 0 then
    raise Exception.Create('Unable to initialize DLL!');
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  DoneDll;
end;

procedure TForm1.btnOpenPortClick(Sender: TObject);
begin
  if OpenPort(PAnsiChar(cbPorts.Text)) <> 0 then
    raise Exception.CreateFmt('Unable to open "%s"',[cbPorts.Text]);
end;

procedure TForm1.btnClosePortClick(Sender: TObject);
begin
  if ClosePort <> 0 then
    raise Exception.Create('Unable to close Port');
end;

procedure TForm1.btnSendClick(Sender: TObject);
var
  s : String;
  rc : Integer;
begin
  s := edtSendText.Text;
  if cbAddCRLF.Checked then
    s := s + #13#10;
  if Length(s) > 0 then
  begin
    rc := WritePort(s[1],Length(s));
    if rc < 0 then
    begin
      if rc = -2 then
        raise Exception.Create('Unable to send because port is busy, retry later!')
      else
        raise Exception.CreateFmt('Unable to send (%d)',[rc])
    end;
  end
  else
    Application.MessageBox('Nothing to send!','Nothing to do',mb_OK);
end;

procedure TForm1.ReceiveData;
var
  buffer : array of Char;
  RequiredBufferLen : Integer;
  rc : Integer;
begin
  SetLength(buffer,0);
  rc := ReadPort(buffer, 0, RequiredBufferLen); //Query the needed buffer size
  if rc = 0 then
  begin
    SetLength(buffer,RequiredBufferLen+1);
    rc := ReadPort(buffer[0], Length(Buffer), RequiredBufferLen);
    if rc > 0 then
      memoTerminal.Lines.Add(PChar(@buffer[0]));
  end;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
  ReceiveData;
end;

end.
