program SerialNGSpyDemo;

uses
  Forms,
  SerialNGSpyDemoMain in 'SerialNGSpyDemoMain.pas' {Form1},
  SerialNGAdv in 'SerialNGAdv.pas' {SerialNGAdvDLG},
  SerialNGWaitClose in 'SerialNGWaitClose.pas' {Form2};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TSerialNGAdvDLG, SerialNGAdvDLG);
  Application.CreateForm(TForm2, Form2);
  Application.Run;
end.
