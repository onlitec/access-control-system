program SerialNGBasicDemo;

uses
  Forms,
  SerialNGBasic in 'SerialNGBasic.pas' {SerialNGBasicDLG},
  SerialNGWaitClose in 'SerialNGWaitClose.pas' {Form2},
  SerialNG2PortDemoMain in 'SerialNG2PortDemoMain.pas' {Form1};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'SerialNG Basic Demo';
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TSerialNGBasicDLG, SerialNGBasicDLG);
  Application.CreateForm(TForm2, Form2);
  Application.Run;
end.
