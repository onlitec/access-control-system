library SerialNGDll;
{
  Hi folks,
  this is an example for the usage of the SerialNG component in a DLL
  First some remarks
  - To make my life easy only one Port object could be created.
    If you want to have more ports working at the same time, you
    could easy extend all function with a parameter "handle" with the
    type DWord or Cardinal, which than passes the the pointer to Port object
  - It is impossible to create the port object in the initialization section
    of the dll, so dont try that
  - before using the port you have to call InitDLL, clean up the mess with a
    call of DoneDLL
  - OpenPort, ClosePort work as expected
  - WritePort will return -2 if the Port is busy with the transmission
    of the previous sended data, than you have to retry
  - ReadPort returns 0 if the size of the received data extends the buffers size.
    You should than extend the buffer to the required size, and recall.

  See the the "SerialNGDllUse.dpr" for more details.
}


uses
  SysUtils,
  Classes,
  SerialNG;

{$R *.res}
// Declaration of functions
// All functions return -1 on general error
// All functions are declared whith cdecl calling convention
  function InitDll : Integer; cdecl; forward;
  procedure DoneDll; cdecl; forward;
  function OpenPort(PortName : PChar) : Integer; cdecl; forward;
  function ClosePort : Integer; cdecl; forward;
  function ReadPort(var Buffer; BufferLen : Integer; var RequiredBufferLen : Integer) : Integer; cdecl; forward;
  function WritePort(var Buffer; BufferLen : Integer) : Integer; cdecl; forward;
// Export of functions
exports
  InitDll,
  DoneDll,
  OpenPort,
  ClosePort,
  ReadPort,
  WritePort;
// Global object variable
// Only on single port is implemented now
var
  SerialPortNG : TSerialPortNG = Nil;

//Implementation of functions
//Here we go with the code

// InitDLL has to be calle prior to every call in the DLL
function InitDll : Integer;
begin
  if not Assigned(SerialPortNG) then
  begin
    SerialPortNG := TSerialPortNG.Create(Nil);
    SerialPortNG.ThreadQuietMode := True; //No event callbacks!
    Result := 0;
  end
  else //Port is all ready created
    Result := -1;
end;
// DoneDLL clean up
procedure DoneDll;
begin
  try
    if Assigned(SerialPortNG) then
    begin
      SerialPortNG.Active := False;
      SerialPortNG.Free;
    end;
  finally
    SerialPortNG := Nil;
  end;
end;
// OpenPort openes the given port
// If the port could not opened, than -2 is returned
function OpenPort(PortName : PChar) : Integer;
begin
  if Assigned(SerialPortNG) then
  begin
    SerialPortNG.CommPort := PortName;
    SerialPortNG.Active := True;
    if SerialPortNG.Active then
      Result := 0
    else
      Result := -2;
  end
  else
    Result := -1;
end;
// ClosePort closes the prio opened port
function ClosePort : Integer;
begin
  if Assigned(SerialPortNG) then
  begin
    SerialPortNG.Active := False;
    Result := 0
  end
  else
    Result := -1;
end;
// ReadPort checkes for available data
// You pass the buffer and the length of the buffer
// If the data fits into the buffer the function returns the copied bytes
// If the data extends the buffer size the function returns 0 and the
// required buffer length in then RequiredBufferLen variable.
// You should then extend the buffer and recall
function ReadPort(var Buffer; BufferLen : Integer; var RequiredBufferLen : Integer) : Integer;
begin
  if Assigned(SerialPortNG) then
  begin
    RequiredBufferLen := SerialPortNG.NextClusterSize;
    if BufferLen < SerialPortNG.NextClusterSize then
      Result := 0 //Buffer to small
    else
    begin
      SerialPortNG.ReadNextClusterAsPChar(PChar(@Buffer));
      Result := RequiredBufferLen;
    end;
  end
  else
    Result := -1;
end;
// WritePort writes the data form the buffer to the port
// if the previous sended data are not completely send the function
// returns -2
function WritePort(var Buffer; BufferLen : Integer) : Integer;
begin
  if Assigned(SerialPortNG) then
  begin
    if SerialPortNG.SendInProgress then
      Result := -2
    else
    begin
      SerialPortNG.SendData(@Buffer,BufferLen);
      Result := 0;
    end;
  end
  else
    Result := -1;
end;

begin
// initialization
// Never initialize any class here, which creates a thread! Windows will
// not allow this and lead into unuseable, undebugable code.
// Since SerialNG creates a thread, it is not allowed to create the object here!!!
end.
