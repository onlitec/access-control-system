unit SerialNGBasic;

interface

uses Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs, StdCtrls,
  Buttons, ExtCtrls, SerialNG;

type
  TSerialNGBasicDLG = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    Bevel1: TBevel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    CBPort: TComboBox;
    CBBaud: TComboBox;
    CBData: TComboBox;
    CBStop: TComboBox;
    CBParity: TComboBox;
    CBFlow: TComboBox;
  private
    { Private declarations }
  public
    { Public declarations }
    procedure SetDLGData(SerialPortNG : TSerialPortNG);
    procedure GetDLGData(SerialPortNG : TSerialPortNG);
  end;
var
  SerialNGBasicDLG: TSerialNGBasicDLG;

implementation

{$R *.DFM}
procedure TSerialNGBasicDLG.SetDLGData(SerialPortNG : TSerialPortNG);
var i : Integer;
begin
  i := CBPort.Items.IndexOf(SerialPortNG.CommPort);
  if i >= 0 then
    CBPort.ItemIndex := i
  else
    CBPort.ItemIndex := 1; //COM2
  i := CBBaud.Items.IndexOf(IntToStr(SerialPortNG.BaudRate));
  if i >= 0 then
    CBBaud.ItemIndex := i
  else
    CBBaud.ItemIndex := 6; // 9600
  i := CBData.Items.IndexOf(IntToStr(SerialPortNG.DataBits)+' Bit');
  if i >= 0 then
    CBData.ItemIndex := i
  else
    CBData.ItemIndex := 4; // 8 Bit
  CBStop.ItemIndex := SerialPortNG.StopBits;
  CBParity.ItemIndex := SerialPortNG.ParityType;
  case SerialPortNG.FlowControl of
    fcNone : CBFlow.ItemIndex := 0;
    fcXON_XOFF : CBFlow.ItemIndex := 1;
    fcRTS_CTS : CBFlow.ItemIndex := 2;
    fcDSR_DTR : CBFlow.ItemIndex := 3;
  else
    CBFlow.ItemIndex := 0;
  end;  
end;

procedure TSerialNGBasicDLG.GetDLGData(SerialPortNG : TSerialPortNG);
begin
  SerialPortNG.CommPort := CBPort.Items[CBPort.ItemIndex];
  SerialPortNG.BaudRate := StrToIntDef(CBBaud.Items[CBBaud.ItemIndex],9600);
  SerialPortNG.DataBits := StrToIntDef(Copy(CBData.Items[CBData.ItemIndex],1,1),8);
  SerialPortNG.StopBits := CBStop.ItemIndex;
  SerialPortNG.ParityType := CBParity.ItemIndex;
  SerialPortNG.FlowControl := BasicFlowModes[CBFlow.ItemIndex];
  SerialPortNG.Active := True;
end;

end.
