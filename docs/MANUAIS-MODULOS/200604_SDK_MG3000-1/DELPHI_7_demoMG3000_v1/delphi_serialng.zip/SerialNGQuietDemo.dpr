program SerialNGQuietDemo;

uses
  Forms,
  SerialNGQuietDemoMain in 'SerialNGQuietDemoMain.pas' {Form1},
  SerialNGBasic in 'SerialNGBasic.pas' {SerialNGBasicDLG};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TSerialNGBasicDLG, SerialNGBasicDLG);
  Application.Run;
end.
