unit SerialNGSpyDemoMain;
{
Hello folks,
this is the "spy" Demo for the SerialPortNG Component.
This program can listen to two talking separate RS232 Devices.
You need a Windows Computer with 2 working and unused serial Ports (e.g. COM1, COM2)
You need a special Cable, builded by Your own: The Spyadapter.
Simply buy (or find in Your home) one piece of an openable 9pin to 25pin adapter.
Also knowed as serial Mouse adapter. Depending from the listeners computer's capabilities
You need additonally one 9pin and one 25pin or two 9 pin female sub d plugs.
Open the Adapter, proof if the connections are as follow

Signal 9Pin side  25Pin Side
DCD     1          8
RXD     2          3
TXD     3          2
DTR     4         20
GND     5          7
DSR     6          6
RTS     7          4
CTS     8          5
RI      9         22

The signals DCD and RI, are sometimes not implemented!
Now solder as follow (Pin numbers are 9 Pin plugs!)
9 Pin Side   9 Pin plug for the listener computer
TXD 3        RXD 2
GND 5        GND 5
DTR 4        DSR 6
RTS 7        CTS 8
Result: all Out Pins of the 9pin plug are patched to Input pins of the the listener computer
Solder now the opposite plug

25 Pin Side   25 Pin plug for the listener computer
TXD  3        RXD  2
RTS  4        CTS  5
GND  7        GBD  7
DTR 20        DSR  6

Plug the adapter between the link of the observed devices,
and the new solderd plugs into the observer computer.

So now COMX will receive what DEV1 is sending, and COMY receive what DEV2 sends
Additionally You may also use a simple Comporttester (has some blinking lights)
*No warranty* for Your Hardware!!!

Plug the stuff together, start the Programm and opens the Ports.
You will see in the Terminal what the attached devices are sending.
You will see the RTS, DTR Lights changing.

Version Info
1.00    24. 03. 2003 First running Version
1.01    07. 10. 2003 New Parameterlist in ProcessError
}


interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,SerialNG,
  StdCtrls, ExtCtrls, ComCtrls, ImgList;

type
  TForm1 = class(TForm)
    SerialPortNG1: TSerialPortNG;
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    Terminal: TMemo;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    Panel1: TPanel;
    AdvSettings1Btn: TButton;
    LedImageList: TImageList;
    PortXImage: TImage;
    CTS1Image: TImage;
    DSR1Image: TImage;
    RxD1Image: TImage;
    Timer1: TTimer;
    ErrorMemo: TMemo;
    Label2: TLabel;
    MaxErrorEdit: TEdit;
    TabSheet4: TTabSheet;
    Memo1: TMemo;
    CBRecordErrors: TCheckBox;
    RxD2Image: TImage;
    DSR2Image: TImage;
    CTS2Image: TImage;
    AdvSettings2Btn: TButton;
    SerialPortNG2: TSerialPortNG;
    RadioGroup1: TRadioGroup;
    RBHex: TRadioButton;
    RBAscii: TRadioButton;
    RBAuto: TRadioButton;
    Image1: TImage;
    LDomIS: TLabel;
    Label1: TLabel;
    procedure AdvSettings2BtnClick(Sender: TObject);
    procedure SerialPortNGRxClusterEvent(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure SaveSettingsBtnClick(Sender: TObject);
    procedure LoadSettingsBtnClick(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure SerialPortNGRxEventCharEvent(Sender: TObject);
    procedure SerialPortNGRxCharEvent(Sender: TObject);
    procedure SerialPortNGCTSEvent(Sender: TObject);
    procedure SerialPortNGDSREvent(Sender: TObject);
    procedure AdvSettings1BtnClick(Sender: TObject);
    procedure LDomISClick(Sender: TObject);
    procedure SerialPortNGProcessError(Sender: TObject; Place,
      Code: Cardinal; Msg: String; Noise: Byte);
  private
    { Private declarations }
    RxD1CharStartTimer : Boolean;
    RxD1CharResetTimer : Boolean;
    RxD2CharStartTimer : Boolean;
    RxD2CharResetTimer : Boolean;
    procedure SetLeds;
    procedure ResetLeds;
    procedure RepaintLeds;
    procedure AddMultiString(S : String; Lines : TStrings );
    procedure OpenBrowser(URL : String);
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
const
  LedGray = 0;
  LedRedOff = 1;
  LedRedOn = 2;
  LedGreenOff = 3;
  LedGreenOn = 4;
  LedYellowOff = 5;
  LedYellowOn = 6;

implementation

uses SerialNGAdv, SerialNGWaitClose,  // Include Advanced Dialog
     Registry, ShellAPI;


{$R *.DFM}
procedure TForm1.AddMultiString(S : String; Lines : TStrings );
var AddS, HexS, CopyS : String;
    i : Integer;
    WorkLen : Integer;
    Delimiter : String;
const AutoLen = 8;
      HexLen = 16;
      AsciiLen = 80;
begin
  Delimiter := '';
  if RBAscii.Checked then
    WorkLen := AsciiLen
  else if RBHex.Checked then
    WorkLen := HexLen
  else
    begin
      WorkLen := AutoLen;
      Delimiter := ' : ';
    end;

  while Length(S) > 0 do
    begin
      AddS := Copy(S,1,WorkLen);
      HexS := '';
      Delete(S,1,WorkLen);
      if RBHex.Checked or RBAuto.Checked then
        for i := 1 to WorkLen do
          begin
            CopyS := Copy(AddS,i,1);
            if CopyS <> '' then
              HexS := HexS + ' ' + Format('%2.2x',[Byte(CopyS[1])])
            else
              HexS := HexS + '   ';
          end;
      if RBAscii.Checked or RBAuto.Checked then
        begin
          for i := 1 to Length(AddS) do
            case AddS[i] of
              #0..#31 : AddS[i] := '�';
              #127    : AddS[i] := '';
            end;
        end;
      if RBHex.Checked then
        AddS := '';
      Lines.Add(HexS+Delimiter+AddS);
    end;
end;

procedure TForm1.AdvSettings1BtnClick(Sender: TObject);
begin
  SerialNGAdvDLG.SetDLGData(SerialPortNG1);
  if SerialNGAdvDLG.ShowModal = mrOK then
    SerialNGAdvDLG.GetDLGData(SerialPortNG1);
  if SerialPortNG1.Active then
    SetLeds
  else
    ResetLeds;
end;

procedure TForm1.AdvSettings2BtnClick(Sender: TObject);
begin
  SerialNGAdvDLG.SetDLGData(SerialPortNG2);
  if SerialNGAdvDLG.ShowModal = mrOK then
    SerialNGAdvDLG.GetDLGData(SerialPortNG2);
  if SerialPortNG2.Active then
    SetLeds
  else
    ResetLeds;
end;

procedure TForm1.SerialPortNGRxClusterEvent(Sender: TObject);
begin
  if TSerialPortNG(Sender).NextClusterSize >= 0 then // Data available?
    begin
      if TSerialPortNG(Sender).NextClusterCCError = 0 then // Error during receiveing?
        Terminal.Lines.Add(FormatDateTime('"Rec  '+TSerialPortNG(Sender).CommPort+'" dd.mm.yy hh:mm:ss" :"', Now))
      else
        Terminal.Lines.Add(FormatDateTime('"RecX '+TSerialPortNG(Sender).CommPort+'" dd.mm.yy hh:mm:ss" :"', Now));
      // Read the data and patch them into the editfield
      AddMultiString(TSerialPortNG(Sender).ReadNextClusterAsString,Terminal.Lines);
    end;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  ResetLeds;
  SerialPortNG1.Active := True;
  if SerialPortNG1.Active then
    SetLeds;
  SerialPortNG2.Active := True;
  if SerialPortNG2.Active then
    SetLeds;
  RxD1CharStartTimer := False;
  RxD1CharResetTimer := False;
  RxD2CharStartTimer := False;
  RxD2CharResetTimer := False;
end;

procedure TForm1.SerialPortNGRxCharEvent(Sender: TObject);
begin
  case TSerialPortNG(Sender).Tag of
    1 : begin
          LedImageList.GetBitmap(LedGreenOn,RxD1Image.Picture.Bitmap);
          RxD1Image.Repaint;
          RxD1CharStartTimer := True;
          RxD1CharResetTimer := False;
        end;
    2 : begin
          LedImageList.GetBitmap(LedGreenOn,RxD2Image.Picture.Bitmap);
          RxD2Image.Repaint;
          RxD2CharStartTimer := True;
          RxD2CharResetTimer := False;
        end;
  end;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
  if RxD1CharResetTimer then // Second Step: Rest Led now
    begin
      LedImageList.GetBitmap(LedGreenOff,RxD2Image.Picture.Bitmap);
      RxD1Image.Repaint;
      RxD1CharStartTimer := False;
      RxD1CharResetTimer := False;
    end;
  if RxD1CharStartTimer then // First Step: Led is On
    RxD1CharResetTimer := True; // Reset the Led in the next Timer Event
  if RxD2CharResetTimer then // Second Step: Rest Led now
    begin
      LedImageList.GetBitmap(LedGreenOff,RxD2Image.Picture.Bitmap);
      RxD2Image.Repaint;
      RxD2CharStartTimer := False;
      RxD2CharResetTimer := False;
    end;
  if RxD2CharStartTimer then // First Step: Led is On
    RxD2CharResetTimer := True; // Reset the Led in the next Timer Event
end;

procedure TForm1.SetLeds;
begin
  if SerialPortNG1.CTSState then
    LedImageList.GetBitmap(LedRedOn,CTS1Image.Picture.Bitmap)
  else
    LedImageList.GetBitmap(LedGreenOn,CTS1Image.Picture.Bitmap);
  if SerialPortNG1.DSRState then
    LedImageList.GetBitmap(LedRedOn,DSR1Image.Picture.Bitmap)
  else
    LedImageList.GetBitmap(LedGreenOn,DSR1Image.Picture.Bitmap);
  LedImageList.GetBitmap(LedGreenOff,RxD1Image.Picture.Bitmap);
  if SerialPortNG2.CTSState then
    LedImageList.GetBitmap(LedRedOn,CTS2Image.Picture.Bitmap)
  else
    LedImageList.GetBitmap(LedGreenOn,CTS2Image.Picture.Bitmap);
  if SerialPortNG2.DSRState then
    LedImageList.GetBitmap(LedRedOn,DSR2Image.Picture.Bitmap)
  else
    LedImageList.GetBitmap(LedGreenOn,DSR2Image.Picture.Bitmap);
  LedImageList.GetBitmap(LedGreenOff,RxD2Image.Picture.Bitmap);
  RepaintLeds;
end;

procedure TForm1.ResetLeds;
begin
  LedImageList.GetBitmap(LedGray,CTS1Image.Picture.Bitmap);
  LedImageList.GetBitmap(LedGray,DSR1Image.Picture.Bitmap);
  LedImageList.GetBitmap(LedGreenOff,RxD1Image.Picture.Bitmap);
  LedImageList.GetBitmap(LedGray,CTS2Image.Picture.Bitmap);
  LedImageList.GetBitmap(LedGray,DSR2Image.Picture.Bitmap);
  LedImageList.GetBitmap(LedGreenOff,RxD2Image.Picture.Bitmap);
  RepaintLeds;
end;


procedure TForm1.SaveSettingsBtnClick(Sender: TObject);
begin
  SerialPortNG1.WriteSettings('Software\DomIS','SerialNGSpyDemoPort1');
  SerialPortNG2.WriteSettings('Software\DomIS','SerialNGSpyDemoPort2');
end;

procedure TForm1.LoadSettingsBtnClick(Sender: TObject);
begin
  SerialPortNG1.ReadSettings('Software\DomIS','SerialNGSpyDemoPort1');
  SerialPortNG2.ReadSettings('Software\DomIS','SerialNGSpyDemoPort2');
end;

procedure TForm1.RepaintLeds;
begin
  CTS1Image.Repaint;
  DSR1Image.Repaint;
  RxD1Image.Repaint;
  CTS2Image.Repaint;
  DSR2Image.Repaint;
  RxD2Image.Repaint;
end;

procedure TForm1.SerialPortNGRxEventCharEvent(Sender: TObject);
begin
  Terminal.Lines.Add(FormatDateTime('"Msg '+TSerialPortNG(Sender).CommPort+'" dd.mm.yy hh:mm:ss" :"', Now)+' RxEventCharEvent occours');
  TSerialPortNG(Sender).ReadRequest := True;
end;

procedure TForm1.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  Form2.Visible := True;
  SerialPortNG1.Active := False;
  CanClose := True;
end;

procedure TForm1.SerialPortNGCTSEvent(Sender: TObject);
begin
  case TSerialPortNG(Sender).Tag of
    1 : begin
          if SerialPortNG1.CTSState then
            LedImageList.GetBitmap(LedRedOn,CTS1Image.Picture.Bitmap)
          else
            LedImageList.GetBitmap(LedGreenOn,CTS1Image.Picture.Bitmap);
          CTS1Image.Repaint;
        end;
    2 : begin
          if SerialPortNG2.CTSState then
            LedImageList.GetBitmap(LedRedOn,CTS2Image.Picture.Bitmap)
          else
            LedImageList.GetBitmap(LedGreenOn,CTS2Image.Picture.Bitmap);
          CTS2Image.Repaint;
        end;
    end;
  if TSerialPortNG(Sender).CTSState then
    Terminal.Lines.Add(FormatDateTime('"Msg '+TSerialPortNG(Sender).CommPort+'" dd.mm.yy hh:mm:ss" :"', Now)+' CTS ON')
  else
    Terminal.Lines.Add(FormatDateTime('"Msg '+TSerialPortNG(Sender).CommPort+'" dd.mm.yy hh:mm:ss" :"', Now)+' CTS OFF')
end;

procedure TForm1.SerialPortNGDSREvent(Sender: TObject);
begin
  case TSerialPortNG(Sender).Tag of
    1 : begin
          if SerialPortNG1.DSRState then
            LedImageList.GetBitmap(LedRedOn,DSR1Image.Picture.Bitmap)
          else
            LedImageList.GetBitmap(LedGreenOn,DSR1Image.Picture.Bitmap);
          DSR1Image.Repaint;
        end;
    2 : begin
          if SerialPortNG2.DSRState then
            LedImageList.GetBitmap(LedRedOn,DSR2Image.Picture.Bitmap)
          else
            LedImageList.GetBitmap(LedGreenOn,DSR2Image.Picture.Bitmap);
          DSR2Image.Repaint;
        end;
  end;
  if TSerialPortNG(Sender).DSRState then
    Terminal.Lines.Add(FormatDateTime('"Msg '+TSerialPortNG(Sender).CommPort+'" dd.mm.yy hh:mm:ss" :"', Now)+' DSR ON')
  else
    Terminal.Lines.Add(FormatDateTime('"Msg '+TSerialPortNG(Sender).CommPort+'" dd.mm.yy hh:mm:ss" :"', Now)+' DSR OFF')
end;
procedure TForm1.OpenBrowser(URL : String);
// Open the standard Browser (if any)
begin
  ShellExecute(Handle,nil,PChar(URL),nil,nil,SW_SHOW)
end;


procedure TForm1.LDomISClick(Sender: TObject);
begin
  OpenBrowser(LDomis.Caption)
end;

procedure TForm1.SerialPortNGProcessError(Sender: TObject; Place,
  Code: Cardinal; Msg: String; Noise: Byte);
var MaxError : Integer;
begin
  if CBRecordErrors.Checked then
    begin
      MaxError := StrToIntDef(MaxErrorEdit.Text,256);
      while ErrorMemo.Lines.Count > MaxError do
        ErrorMemo.Lines.Delete(0);
      ErrorMemo.Lines.Add(FormatDateTime('"Msg  '+TSerialPortNG(Sender).CommPort+'" dd.mm.yy hh:mm:ss" :"', Now)+Format('Code %d at %d Text: %s',[Code,Place,Msg]));
    end;

end;

end.
