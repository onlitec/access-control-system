unit SerialNGBasicDemoMain;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, ExtCtrls, SerialNG;

type
  TForm1 = class(TForm)
    BasicSettingsBtn: TButton;
    Terminal: TMemo;
    Label1: TLabel;
    Edit1: TEdit;
    SendBtn: TButton;
    CBAddCRLF: TCheckBox;
    SerialPortNG1: TSerialPortNG;
    procedure BasicSettingsBtnClick(Sender: TObject);
    procedure SerialPortNG1RxClusterEvent(Sender: TObject);
    procedure SendBtnClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

uses SerialNGBasic;
{$R *.DFM}
procedure AddHexString(S : String; Lines : TStrings );
var AddS, HexS, CopyS : String;
    i : Integer;
const SLen = 8;
begin
  while Length(S) > 0 do
    begin
      AddS := Copy(S,1,SLen);
      HexS := '';
      Delete(S,1,SLen);
      for i := 1 to SLen do
        begin
          CopyS := Copy(AddS,i,1);
          if CopyS <> '' then
            HexS := HexS + ' ' + Format('%2.2x',[Byte(CopyS[1])]) //
          else
            HexS := HexS + '   ';
        end;
       while Length(AddS) < SLen do
         AddS := AddS + ' ';
       for i := 1 to SLen do
         case AddS[i] of
           #0..#31 : AddS[i] := '.';
           #127    : AddS[i] := '.';
         end;
       Lines.Add(HexS+' : '+AddS);
    end;
end;

procedure TForm1.BasicSettingsBtnClick(Sender: TObject);
begin
  SerialNGBasicDLG.SetDLGData(SerialPortNG1);
  if SerialNGBasicDLG.ShowModal = mrOK then
    SerialNGBasicDLG.GetDLGData(SerialPortNG1);
end;

procedure TForm1.SerialPortNG1RxClusterEvent(Sender: TObject);
begin
  if SerialPortNG1.NextClusterSize >= 0 then
    begin
      if SerialPortNG1.NextClusterCCError = 0 then
        Terminal.Lines.Add(FormatDateTime('"Rec  " dd.mm.yy hh:mm:ss" :"', Now))
      else
        Terminal.Lines.Add(FormatDateTime('"RecX " dd.mm.yy hh:mm:ss" :"', Now));
      AddHexString(SerialPortNG1.ReadNextClusterAsString,Terminal.Lines);
    end;

end;

procedure TForm1.SendBtnClick(Sender: TObject);
var SendStr : String;
begin
  if Length(Edit1.Text) > 0 then
    begin
      Terminal.Lines.Add(FormatDateTime('"Snd " dd.mm.yy hh:mm:ss" :"', Now));
      Terminal.Lines.Add(Edit1.Text);
      SendStr := Edit1.Text;
      if CBAddCRLF.Checked then
        SendStr := SendStr+#$0d#$0a;
      SerialPortNG1.SendString(SendStr);
    end;
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  SerialPortNG1.Active := False;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  SerialPortNG1.Active := True;
end;

end.
