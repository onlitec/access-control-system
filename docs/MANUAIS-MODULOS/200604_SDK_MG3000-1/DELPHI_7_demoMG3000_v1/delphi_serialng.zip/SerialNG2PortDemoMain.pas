unit SerialNG2PortDemoMain;
// 21.3.2002 Changes and Bugfixes:
//           Send and Receive shows the PortName
//           Settings for Port2 repaired
interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, ExtCtrls, SerialNG;

type
  TForm1 = class(TForm)
    BasicSettingsBtn1: TButton;
    Terminal: TMemo;
    Label1: TLabel;
    Edit1: TEdit;
    SendBtn1: TButton;
    CBAddCRLF: TCheckBox;
    SerialPortNG1: TSerialPortNG;
    BasicSettingsBtn2: TButton;
    SerialPortNG2: TSerialPortNG;
    SendBtn2: TButton;
    procedure BasicSettingsBtn1Click(Sender: TObject);
    procedure SerialPortNGRxClusterEvent(Sender: TObject);
    procedure SendBtn1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure BasicSettingsBtn2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

uses SerialNGBasic, SerialNGWaitClose;
{$R *.DFM}
procedure AddHexString(S : String; Lines : TStrings );
var AddS, HexS, CopyS : String;
    i : Integer;
const SLen = 8;
begin
  while Length(S) > 0 do
    begin
      AddS := Copy(S,1,SLen);
      HexS := '';
      Delete(S,1,SLen);
      for i := 1 to SLen do
        begin
          CopyS := Copy(AddS,i,1);
          if CopyS <> '' then
            HexS := HexS + ' ' + Format('%2.2x',[Byte(CopyS[1])]) //
          else
            HexS := HexS + '   ';
        end;
       while Length(AddS) < SLen do
         AddS := AddS + ' ';
       for i := 1 to SLen do
         case AddS[i] of
           #0..#31 : AddS[i] := '.';
           #127    : AddS[i] := '.';
         end;
       Lines.Add(HexS+' : '+AddS);
    end;
end;

procedure TForm1.BasicSettingsBtn1Click(Sender: TObject);
begin
  SerialNGBasicDLG.SetDLGData(SerialPortNG1);
  if SerialNGBasicDLG.ShowModal = mrOK then
    SerialNGBasicDLG.GetDLGData(SerialPortNG1);
  if SerialPortNG1.Active then
    SendBtn1.Enabled := True
  else
    SendBtn1.Enabled := False;
end;

procedure TForm1.SerialPortNGRxClusterEvent(Sender: TObject);
begin
  case TSerialPortNG(Sender).Tag of
    1 : if SerialPortNG1.NextClusterSize >= 0 then
          begin
            if SerialPortNG1.NextClusterCCError = 0 then
              Terminal.Lines.Add(FormatDateTime('"Rec  '+SerialPortNG1.CommPort+'" dd.mm.yy hh:mm:ss" :"', Now))
            else
              Terminal.Lines.Add(FormatDateTime('"RecX '+SerialPortNG1.CommPort+'" dd.mm.yy hh:mm:ss" :"', Now));
            AddHexString(SerialPortNG1.ReadNextClusterAsString,Terminal.Lines);
          end;
    2 : if SerialPortNG2.NextClusterSize >= 0 then
          begin
            if SerialPortNG2.NextClusterCCError = 0 then
              Terminal.Lines.Add(FormatDateTime('"Rec  '+SerialPortNG2.CommPort+'" dd.mm.yy hh:mm:ss" :"', Now))
            else
              Terminal.Lines.Add(FormatDateTime('"RecX '+SerialPortNG2.CommPort+'" dd.mm.yy hh:mm:ss" :"', Now));
            AddHexString(SerialPortNG2.ReadNextClusterAsString,Terminal.Lines);
          end;
  end;
end;

procedure TForm1.SendBtn1Click(Sender: TObject);
var SendStr : String;
begin
  if Length(Edit1.Text) > 0 then
    begin
      if TButton(Sender).Tag = 1 then
        Terminal.Lines.Add(FormatDateTime('"Snd  '+SerialPortNG1.CommPort+'" dd.mm.yy hh:mm:ss" :"', Now))
      else
        Terminal.Lines.Add(FormatDateTime('"Snd  '+SerialPortNG2.CommPort+'" dd.mm.yy hh:mm:ss" :"', Now));
      Terminal.Lines.Add(Edit1.Text);
      SendStr := Edit1.Text;
      if CBAddCRLF.Checked then
        SendStr := SendStr+#$0d#$0a;
      if TButton(Sender).Tag = 1 then
        SerialPortNG1.SendString(SendStr)
      else
        SerialPortNG2.SendString(SendStr)
    end;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  SerialPortNG1.Active := True;
  if SerialPortNG1.Active then
    SendBtn1.Enabled := True
  else
    SendBtn1.Enabled := False;
  SerialPortNG2.Active := True;
  if SerialPortNG2.Active then
    SendBtn2.Enabled := True
  else
    SendBtn2.Enabled := False;
end;

procedure TForm1.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  Form2.Visible := True;
  CanClose := True;
  SerialPortNG1.Active := False;
  SerialPortNG2.Active := False;
end;

procedure TForm1.BasicSettingsBtn2Click(Sender: TObject);
begin
  SerialNGBasicDLG.SetDLGData(SerialPortNG2);
  if SerialNGBasicDLG.ShowModal = mrOK then
    SerialNGBasicDLG.GetDLGData(SerialPortNG2);
  if SerialPortNG2.Active then
    SendBtn2.Enabled := True
  else
    SendBtn2.Enabled := False;
end;

end.
