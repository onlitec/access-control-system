unit SerialNGStressMain;
{
Hello folks,
this is the Stress Demo for the SerialPortNG Component.
The Programm creates Telegrams composed from
<STX><TELEGRAM_NUMBER><SOME_DATA><CHECK_SUM><ETX>
everything inside the <STX><ETX> pair is fromatted in HEX Chars
so it is possibly to use 7 Bit transmission.
Normally You use two computers with a crossover Cable, but You can use
a Testadapter with loopback and use the program on a single Computer.
See SerialNGAdvDemo.pas how build such a adapter

The Source is a bit "Quick and Dirty" because i did not have enought Time to
made the source nice :-)
}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, ExtCtrls, SerialNG;

type
  TForm1 = class(TForm)
    BasicSettingsBtn: TButton;
    Terminal: TMemo;
    SerialPortNG1: TSerialPortNG;
    RunBtn: TButton;
    Timer1: TTimer;
    Label1: TLabel;
    LErrorCount: TLabel;
    Label2: TLabel;
    LTelegrams: TLabel;
    procedure BasicSettingsBtnClick(Sender: TObject);
    procedure SerialPortNG1RxClusterEvent(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure RunBtnClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    Run : Boolean;
    TeleNr : Integer;
    OldTeleNr : Integer;
    ErrorCount : Integer;
    RecTelegrams : Integer;
    procedure SendTelegram;
    function AnalyseTelegram(S : String) : Boolean;
    procedure LogMemo(Lines : TStrings; S : String);
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

uses SerialNGBasic;
{$R *.DFM}
procedure TForm1.BasicSettingsBtnClick(Sender: TObject);
begin
  SerialNGBasicDLG.SetDLGData(SerialPortNG1);
  if SerialNGBasicDLG.ShowModal = mrOK then
    SerialNGBasicDLG.GetDLGData(SerialPortNG1);
end;

procedure TForm1.SerialPortNG1RxClusterEvent(Sender: TObject);
var S : String;
begin
  if SerialPortNG1.NextClusterSize >= 0 then
    begin
      if SerialPortNG1.NextClusterCCError = 0 then
        begin
          S := SerialPortNG1.ReadNextClusterAsString;
          LogMemo(Terminal.Lines,FormatDateTime('"Rec  " dd.mm.yy hh:mm:ss" :"', Now));
          LogMemo(Terminal.Lines,S);
          if AnalyseTelegram(S) then
            begin
              Inc(RecTelegrams);
              LTelegrams.Caption := IntToStr(RecTelegrams);
              SendTelegram;
            end;
        end
      else
        begin
          S := SerialPortNG1.ReadNextClusterAsString;
          LogMemo(Terminal.Lines,FormatDateTime('"RecX " dd.mm.yy hh:mm:ss" :"', Now));
          Inc(ErrorCount);
          LErrorCount.Caption := IntToStr(ErrorCount);
        end
    end;
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  SerialPortNG1.Active := False;
end;

procedure TForm1.RunBtnClick(Sender: TObject);
begin
  if Run then
    begin
      SerialPortNG1.Active := False;
      if not SerialPortNG1.Active then
        begin
          RunBtn.Caption := '&Run';
          Run := False;
        end;
    end
  else
    begin
      SerialPortNG1.Active := True;
      if SerialPortNG1.Active then
        begin
          RunBtn.Caption := '&Stop';
          Run := True;
        end;
    end;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
  if Run then
    begin
      if OldTeleNr = TeleNr then
        begin
          if TeleNr >= 0 then
            LogMemo(Terminal.Lines,'Timeout!')
          else
            TeleNr := 0;
          if not SerialPortNG1.SendInProgress then
            SendTelegram;
        end;
      OldTeleNr := TeleNr;
    end;
end;

procedure TForm1.SendTelegram;
var Tele : String;
    TeleNrStr : String;
    TeleDataStr : String;
    TeleCheckSumStr : String;
    i,d, cs : Integer;
begin
  TeleNrStr := Format('%8.8x',[TeleNr]);
  TeleDataStr := '';
  for i := 1 to 64 do
    begin
      d := Random(255);
      TeleDataStr := TeleDataStr + Format('%2.2x',[d]);
    end;
  cs := 0;
  Tele := TeleNrStr + TeleDataStr;
  for i := 1 to Length(Tele) div 2 do
    cs := cs xor StrToInt('$'+Copy(Tele,i*2-1,2));
  TeleCheckSumStr := Format('%2.2x',[cs]);
  Tele := #2+Tele+TeleCheckSumStr+#3;
  if not SerialPortNG1.SendInProgress then
    SerialPortNG1.SendString(Tele);
  LogMemo(Terminal.Lines,FormatDateTime('"Snd  " dd.mm.yy hh:mm:ss" :"', Now));
  LogMemo(Terminal.Lines,Tele);
end;

function TForm1.AnalyseTelegram(S : String) : Boolean;
var Error : String;
    TeleNrStr : String;
    TeleDataStr : String;
    TeleCheckSumStr : String;
    CSStr : String;
    v : Integer;
    NewTeleNr : Integer;
    TeleCS : Integer;
    Work : Boolean;
    CState : Integer;
begin
  CState := 0;
  v := 0;
  NewTeleNr := 0;
  TeleCS := 0;
  Work := True;
  while Work do
    begin
      case CState of
        0 : begin
              if S[1] <> #2 then
                begin
                  Error := '<STX> expected';
                  Work := False
                end
              else
                CState := 1;
            end;
        1 : begin
              if S[Length(S)] <> #3 then
                begin
                  Error := '<ETX> expected';
                  Work := False
                end
              else
                CState := 2;
            end;
        2 : begin
              System.Delete(S,1,1);
              System.Delete(S,Length(S),1);
              TeleNrStr := Copy(S,1,8);
              if Length(TeleNrStr) <> 8 then
                begin
                  Error := 'TeleNr is not 8 Chars long';
                  Work := False
                end
              else
                begin
                  try
                    NewTeleNr := StrToInt('$'+TeleNrStr);
                    CState := 3;
                  except
                    Error := 'TeleNr is not a Number';
                    Work := False
                  end;
                end;
            end;
        3 : begin
              TeleDataStr := Copy(S,9,128);
              if Length(TeleDataStr) <> 128 then
                begin
                  Error := 'TeleData is not 64 Chars long';
                  Work := False;
                end
              else
                CState := 4;
            end;
        4 : begin
              TeleCheckSumStr := Copy(S,137,2);
              if Length(TeleCheckSumStr) <> 2 then
                begin
                  Error := 'TeleCheckSumStr is not 2 Chars long';
                  Work := False;
                end
              else
                begin
                  try
                    TeleCS := StrToInt('$'+TeleCheckSumStr);
                    CState := 5;
                  except
                    Error := 'TeleCheckSum is not a Number';
                    Work := False;
                  end;
                end;
            end;
        5 : begin
              CSStr := TeleNrStr + TeleDataStr;
              v := 0;
              while Length(CSStr) > 0 do
                begin
                  try
                    v := v xor StrToInt('$'+Copy(CSStr,1,2));
                    System.Delete(CSStr,1,2);
                    CState := 6;
                  except
                    Error := 'Datapart not a Number';
                    CSStr := '';
                    Work := False;
                  end;
                end;
            end;
        6 : begin
              if TeleCS <> v then
                Error := 'Checksum not equal';
              Work := False;
            end;
      else
        Error := 'Undefined CState';
        Work := False;
      end
    end; //while work...
  if Error <> '' then
    begin
      AnalyseTelegram := False;
      LogMemo(Terminal.Lines,Error);
      Inc(ErrorCount);
      LErrorCount.Caption := IntToStr(ErrorCount);
    end
  else
    begin
      TeleNr := NewTeleNr + 1;
      AnalyseTelegram := True;
    end;
end;

procedure TForm1.LogMemo(Lines : TStrings; S : String);
begin
  while Lines.Count > 512 do
    Lines.Delete(Lines.Count-1);
  Lines.Insert(0,S);
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  Run := False;
  TeleNr := -1;
  OldTeleNr := -1;
  ErrorCount := 0;
  RecTelegrams := 0;
  SerialPortNG1.ErrorNoise := enError;
end;

end.
