DomIS Internet Solution http://www.domis.de
Fully Serial Communication with Delphi and Windows 95/98/Me/NT/2000/XP
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Official SerialNG Hompage http://www.domis.de/serialng.htm
There is an User forum availaible: http://www.domis.de/forum.htm
Documentation: For a full Description see http://www.domis.de/serialngdoc.htm
Installation: For a full Description see http://www.domis.de/serialnginst.htm

Licence:
This Software is free for Open-Source Projects (GNU-License)
This Software is free for Closed-Source Projects if 
- this Source is included in the Distribution of the Project, and
- in the AboutBox or an other simmilar Place the String "Created with SerialNG from DomIS http://www.domis.de" is included. Translation is allowed
If You want to use this tool without the above condition (Source is total hidden) then call me first.

Donation:
Support the development of SerialNG with a donation. Any amount will be welcome
You may transmit the Money to my  Bank-Account
Kto. 654130-604, Postbank Frankfurt/M, BLZ 500 100 60, Kennwort SerialNG
for International transmission, use the IBAN Code
IBAN DE 56 5001 0060 0654 1306 04
You may also use Paypal if You like
Link for EURO transmission
https://www.paypal.com/xclick/business=paypal%40domis.de&item_name=Support+SerialNG+Development&item_number=SerialNG-EUR&tax=0&currency_code=EUR
Link for USD transmission
https://www.paypal.com/xclick/business=paypal%40domis.de&item_name=Support+SerialNG+Development&item_number=SerialNG-USD&tax=0&currency_code=USD
Thank You for using and supporting SerialNG!

Install:
There are two DPK files attached, for Delphi4 and Delphi2005
Take a look to http://www.domis.de/serialnginst.htm

Demos:
There are Demos. Open the *.dpr file and compile
SerialNGBasicDemo: A very simple Demo, includes the absolute minimum of use of the component
SerialNGAdvDemo:   A complex Demo, which uses a lot of the cpabilities og the component
SerialNGStress:    A Demo to test the transmission for errors.
SerialNG2PortDemo: A Demo how to work with more than one Port
SerialNGSpyDemo:   Demo Program to observe a serial communication
SerialNGStateMachineDemo: Example of multistate Modem/Device communication
SerialNGDll and SerialNGDllUse: A very simple Demo, showing the usage of the component in a DLL

Have fun and success
Best Regards
Ekkehard Domning