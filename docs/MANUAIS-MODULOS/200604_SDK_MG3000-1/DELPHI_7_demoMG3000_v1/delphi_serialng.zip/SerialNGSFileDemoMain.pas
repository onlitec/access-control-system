unit SerialNGSFileDemoMain;

{
  SerialNG SendFile Demo
  This Source demonstrate the handling of larger amount of Data.
  This Program let You open a File and send the contents via a selected
  Com Port.
  How ever there is no protocol implemented and no specific error management.
  To see how to receive larger amount of Data use the SerialNGRFileDemo Project.
}


interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, ExtCtrls, SerialNG, ComCtrls;

type
  TForm1 = class(TForm)
    BasicSettingsBtn: TButton;
    SendBtn: TButton;
    SerialPortNG1: TSerialPortNG;
    OpenDialog1: TOpenDialog;
    FChooserBtn: TButton;
    FNameEdit: TEdit;
    Label1: TLabel;
    ProgressBar1: TProgressBar;
    Label2: TLabel;
    StopBtn: TButton;
    procedure BasicSettingsBtnClick(Sender: TObject);
    procedure SerialPortNG1RxClusterEvent(Sender: TObject);
    procedure SendBtnClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure SerialPortNG1WriteDone(Sender: TObject);
    procedure StopBtnClick(Sender: TObject);
    procedure FChooserBtnClick(Sender: TObject);
  private
    { Private declarations }
    FName : String;
    FSize : Integer;
    FTxByte : Integer;
    FHandle: File;
    Buffer : array[0..1024] of Char;
    FileIsOpen : Boolean;
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

uses SerialNGBasic;
{$R *.DFM}
procedure TForm1.BasicSettingsBtnClick(Sender: TObject);
begin
  SerialNGBasicDLG.SetDLGData(SerialPortNG1);
  if SerialNGBasicDLG.ShowModal = mrOK then
    SerialNGBasicDLG.GetDLGData(SerialPortNG1);
end;

procedure TForm1.SerialPortNG1RxClusterEvent(Sender: TObject);
// Discard any received data, to hold the InputQueue clean
begin
  if SerialPortNG1.NextClusterSize >= 0 then
    SerialPortNG1.ReadNextClusterAsString;
end;

procedure TForm1.SendBtnClick(Sender: TObject);
// The User want to send a File
var NumRead : Integer;
begin
  FName := FNameEdit.Text; // Save the Name of the Send File
  if FName = '' then //Is Empty? Done!
    begin
      Application.MessageBox('You must enter a Filename!','Error',mb_iconstop or mb_Ok);
      Exit;
    end;
  {$I-}
  AssignFile(FHandle, FName); // Try to open the File
  FileMode := 0;
  Reset(FHandle,1);
  {$I+}
  if (IOResult <> 0) then // Open with Errors? Done!
    begin
      {$I-}
      System.Close(FHandle);
      {$I+}
      Application.MessageBox('Can''t open File!','Error',mb_iconstop or mb_Ok);
      Exit;
    end;
  {$I-}
  FSize := FileSize(FHandle);
  {$I+}
  if (FSize <= 0) then // Filesize is Zero, File is Empty? Done!
    begin
      {$I-}
      System.Close(FHandle);
      {$I+}
      Application.MessageBox('File is empty!','Error',mb_iconstop or mb_Ok);
      Exit;
    end;
  FileIsOpen := True; // Ok, the File ist Open
  ProgressBar1.Max := FSize; // Set the Max value of the Progressbar to the Filesize
  StopBtn.Enabled := True; // Enable the Stop Button
  SendBtn.Enabled := False; // Disable the Send Button, to prevent multiple Sendinings
  BlockRead(FHandle, Buffer, SizeOf(Buffer), NumRead); // Read the First 1k of the File
  FTxByte := NumRead; //Save the readed Bytes
  SerialPortNG1.SendData(@Buffer, NumRead); //Send the binary Data
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  if FileIsOpen then
    System.CloseFile(FHandle); // Close the file
  SerialPortNG1.Active := False;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  FileIsOpen := False;
  SerialPortNG1.Active := True;
end;

procedure TForm1.SerialPortNG1WriteDone(Sender: TObject);
// This is called when the SerialPort has transmitted the Data
var NumRead : Integer;
begin
  if FileIsOpen then // If FileIsOpen
    begin
      ProgressBar1.Position := FTxByte; // Show the transmited Amount
      BlockRead(FHandle, Buffer, SizeOf(Buffer), NumRead); // Read the Next Part of the File (if any)
      FTxByte := FTxByte + NumRead; // Add the Amount, for the Progressbar
      if NumRead > 0 then // If any Data read...
        SerialPortNG1.SendData(@Buffer, NumRead); //send them!
      if NumRead < SizeOf(Buffer) then // If less data readed than expected, the end of the file is reached
        begin
          ProgressBar1.Position := FTxByte; // Show the transmited Amount
          System.CloseFile(FHandle); // Close the file
          FileIsOpen := False; //Remember the file is closed
          StopBtn.Enabled := False; // No Stop is possible
          SendBtn.Enabled := True; //Next Send is now possible
        end;
    end
  else
    begin // If the file is closed...
      SendBtn.Enabled := True; //We can send new Data if the remaind Data are send
    end;
end;

procedure TForm1.StopBtnClick(Sender: TObject);
begin
  if FileIsOpen then
    begin
      System.CloseFile(FHandle); // Close the File
      FileIsOpen := False; // Remember this
      StopBtn.Enabled := False; //Allow no to stop again
      // You may Expect to enable the Sendbutton here, but this could cause problems!
    end;
end;

procedure TForm1.FChooserBtnClick(Sender: TObject);
begin
  if OpenDialog1.Execute then
    FNameEdit.Text := OpenDialog1.FileName;
end;

end.
