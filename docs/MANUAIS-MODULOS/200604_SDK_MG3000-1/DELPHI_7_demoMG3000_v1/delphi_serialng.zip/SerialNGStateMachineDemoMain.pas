unit SerialNGStateMachineDemoMain;
{
  This Demo shows how to implement a more complex communication.
  To see this demo running You must have a modem attached at one
  Commport. Some onboard oder card Modems and some ISDN Cards will
  work to, if they are properly registered in the registry.
  After starting the Program shows a ComboBox with Your commports, plus
  a invalid entry to see how the program works on invalid commportnames.
  Select one entry.
  Press the 'Go' Button.
  If the port is opened
  serveral commands to the modem are send (AT, ATI1..n, AT+FCLASS=?)
  after all the port is closed.
  This straight way is possibly interrupted by the folowing conditions
  - The port could not be openened
  - there is no device attached, so we will get no response
  - there is a different device attached, so we get different answers
  - not all modems understand the same stuff
  - windows detect communication errors
  Some of the errors could be fixed, e.g. attaching a modem on no response
  some will lead to abortion.

  I made a "Statemachine". This piece of software is feeded by events
  - Reception from the Port
  - Errors from the Port
  - Timeouts from the Timer
  - Action from the Buttons
  depending of the current state and the class of event or error the
  machine will be driven into the next or a save position.

  The procedure may be (simply?) extended or modified.
  Anyway the whole stuff looks a bit overdresse for the very few commands
  but making bigger protocols, using a Statemachine, is IMHO, the only way.
}
interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, SerialNG, ExtCtrls;

type
  TForm1 = class(TForm)
    Panel1: TPanel;
    Panel2: TPanel;
    memoLog: TMemo;
    cbPorts: TComboBox;
    btnStart: TButton;
    btnStop: TButton;
    SerialPortNG1: TSerialPortNG;
    Timer1: TTimer;
    btnCrash: TButton;
    procedure FormCreate(Sender: TObject);
    procedure btnStartClick(Sender: TObject);
    procedure btnStopClick(Sender: TObject);
    procedure SerialPortNG1RxClusterEvent(Sender: TObject); //Receiver
    procedure SerialPortNG1WriteDone(Sender: TObject);      //Not yet used
    procedure Timer1Timer(Sender: TObject);                 //Timer
    procedure SerialPortNG1ProcessError(Sender: TObject; Place,
      Code: Cardinal; Msg: String; Noise: Byte); //Errors from the Commport
    procedure btnCrashClick(Sender: TObject);    //Crash closes the port during work
  private
    { Private-Deklarationen}
    TimerCountDown : Integer; //The TimeOutCounter
    RetryCtr : Integer;       //The Retry Counter, "attach Modem now"
    TrailState : Integer;     //The State of the Statemachine
    LastTrailState : Integer; //The previous State
    ATICtr : Integer;         //A Counter for the ATIx commands
    procedure LogMsg(Msg : String);  //Prints the Msg into the Memo
    procedure SetTimeOut(Sec : Integer);  //Sets the Timeout
    procedure StopTimeOut;                //Resets the Timout
    procedure WorkTrail(MsgType : Integer; Msg : String); //The Statemachine
  public
    { Public-Deklarationen}
  end;

var
  Form1: TForm1;


implementation
uses CommPortList;
{$R *.DFM}

const
{ TrailState constants
  Add some for Your application
}
  tsIdle          = 0;
  tsActivate      = 1;
  tsAT            = 2;
  tsWaitForATOK   = 3;
  tsATIn          = 4;
  tsWaitForATIn   = 5;
  tsATFCLASS      = 6;
  tsWaitForATFCLASS = 7;

  tsErrNoPort  = 70;
  tsErrComm    = 71;
  tsErrCheck   = 72;
  tsErrATOK    = 73;
  tsErrTimeOut = 74;
  tsPrepStop   = 90;
  tsFinal      = 100;

//MsgType const
  msError      = 1;  //Error from the commport
  msTimeOut    = 2;  //Timeout occours
  msStartBtn   = 3;  //Startbutton pressed
  msStopBtn    = 4;  //Stopbutton pressed
  msReceiver   = 5;  //Received data


{ Log the Message into the Memo field}
procedure TForm1.LogMsg(Msg : String);
begin
  memoLog.Lines.Add(Msg);
end;
{ The Timer runs with 250ms, so set the Timer to
  4*Sec, add 250ms because the Timer is free running}
procedure TForm1.SetTimeOut(Sec : Integer);
begin
  if Sec > 0 then
    TimerCountDown := Sec*4 + 1
  else
    TimerCountDown := 1;
end;
{ Stop Timeout, no TimeOut will be generated}
procedure TForm1.StopTimeOut;
begin
  TimerCountDown := 0;
end;
{
  Here comes the core of the software:
  Each Event that can modify the state will be routed
  into this procedure.
}
procedure TForm1.WorkTrail(MsgType : Integer; Msg : String);
var Done : Boolean;
    { Some tasks could/must be performed without waiting for
      a new event, so 'Done' will indicate if we are finished
      with our job for now }
    LtsAlertCtr : Integer;
    { Since You are not a perfect programmer like me ;-)
      I made a Trap to catch Problems with forgotten 'Done := True'
      statements }

begin
  LtsAlertCtr := 0;  //neues Spiel, neues Gl�ck (new Game, new luck?)
  LastTrailState := TrailState; //Save the previous state
  { Some Messages can/must be worked in a 'global' way }
  if MsgType = msStopBtn then
    TrailState := tsPrepStop //Stop button pressed, prepare to stop
  else if MsgType = msError then
    TrailState := tsErrCheck //Error from the Commport, check if we can do something
  else if MsgType = msTimeOut then
    TrailState := tsErrTimeOut; //Timeout occour
  Done := True; //usually we will *not* loop around
  repeat
  { First the 'Done=False' Trap
    If the State is not changed during looping we will count the
    loop, if we have 10 Times looped without change, break.
    If there is a change in state reset the counter.
    If You are a perfect programmer - remove this stuff
  }

    if TrailState = LastTrailState then
      Inc(LtsAlertCtr)
    else
      LtsAlertCtr := 0;
    if LtsAlertCtr > 10 then
      begin
        LogMsg('FATAL: Your Software can not find out from State "'+IntToStr(TrailState)+'"');
        Exit;
      end;
  { Trap end }

  {
     No distribute the states of the machine
  }

    case TrailState of
      { Idle, the Program has been started, or the job has been finished
        here we wait to the start button }
      tsIdle :
        begin
          if MsgType = msStartBtn then
            begin  //Yes the Startbutton has been pressed
              LogMsg('State: tsIdle. '+Msg);   //Log the event
              { This is important:
                Now we change the State to the next State, where we will
                open the port.
                You could also open the port here, but than You can not
                Program a retry on failure without code duplication
              }
              TrailState := tsActivate;
              { Done is set to False to loop around to the tsActivate state }
              Done := False;
            end;
        end;
      { Activate the Port and if move to the first send }
      tsActivate :
        begin
          Done := False; //Nearly all following steps are done without leaving the procedure
          RetryCtr := 10;  //Init the Retry Counter
          btnStart.Enabled := False; //Set the Ok and Stop Button
          btnStop.Enabled := True;
          LogMsg('State: tsActivate. Try to open port'); //Log the state
          if cbPorts.ItemIndex >= 0 then //Check if the CopmboBox has something selected
            begin
              { Assuming everything runs well, the next state will be
                sending the AT String to the modem
                It is important to set this State *before* working on the
                Serial Port (I explane bewlo)}
              TrailState := tsAT;
              { Set the commport name }
              SerialPortNG1.CommPort := cbPorts.Items[cbPorts.ItemIndex];
              { OK, try no to open the Port, if this fail, this procedure is
                *recursively* called by the SerialNG component, wich will be terminate
                this work }
              SerialPortNG1.Active := True;
              SerialPortNG1.FlowControl := fcDSR_DTR; //Hardware Flowcontrol
              { Checking for a open port could be done also by checking if the
                TrailState is no longer tsActivate (Recusive call!!)
                But this looks not so fine.
              }
              if not SerialPortNG1.Active then
              { Select the ComErr from the ComboBox and set a Breakpoint
                here. Check the value of TrailState Ctrl-F7 You will see
                that the errorbusines is allready done
                So here we leave the procedure}
                Done := True;
            end
          else // No entry is selected in the ComboBox
            TrailState := tsErrNoPort;
        end;
      { The Port is open now we can send the 'AT' command to the modem }
      tsAT :
        begin
          LogMsg('State: tsAT. Try to send AT'); //Log the state
          TrailState := tsWaitForATOK;           //Set the Next State
          SetTimeOut(1); //Wait 1 Sec
          { Again, setting the next State prior the work on the commport!!
            If SendString fail, error business will, recursivly
            take place.
            If After this the State is set to the next step this will lead
            into desaster}
          SerialPortNG1.SendString('AT'#$0d);    //Send the String
          Done := True; //We have to wait, so leaving
        end;
      { We are waiting for an Acknowledge to our AT}
      tsWaitForATOK :
        begin
          LogMsg('State: tsWaitForAT. Received "'+Msg+'"'); //Update Log
          StopTimeOut;    //Stop running TimeOut
          Done := False;  //We have to do something more
          Msg := Trim(Msg);
          if Copy(Msg,Length(Msg)-1,2) = 'OK' then //Ok received
            begin
              ATICtr := 1; //ATI commands start a ATI1 and runs up to ATI9
              TrailState := tsATIn; //Next Step
            end
          else
            TrailState := tsErrATOK; //No OK received, done
        end;
      { This step is a multiple Step, it will be performed serveral times
        for each ATIn }
      tsATIn :
        begin
          LogMsg('State: tsATn. Sending ATI'+IntToStr(ATICtr)); //Log the State
          TrailState := tsWaitForATIn; //Set the Next state prior the action
          SetTimeOut(1); //Wait 1 Sec
          SerialPortNG1.SendString('ATI'+IntToStr(ATICtr)+#$0d); //Send the command
          Done := True; //Leave
        end;
      { This step is a multiple Step, it will be performed serveral times
        for each ATIn }
      tsWaitForATIn :
        begin
          LogMsg('State: tsWaitForATIn. Received "'+Msg+'"'); //update Log
          StopTimeOut;
          Done := False;
          Msg := Trim(Msg);
          if Copy(Msg,Length(Msg)-4,5) = 'ERROR' then
          { We received an ERROR String from the Modem, this shows us, that
            the modem can not understand the ATIn (n=ATICtr) command.
            Some Modems understand ATI8 some also ATI9
            Anyway we move to the next command
          }
            TrailState := tsATFCLASS
          else
            begin
              if ATICtr < 10 then
              { We loop thu all ATI1 .. ATI10 commands }
                begin
                  Inc(ATICtr);
                  TrailState := tsATIn;
                end
              else
              { In the case that the Modem sends something different than
                ERROR, or we have a bug in detection, we abort after 10 ATIn
                Commands }
                TrailState := tsATFCLASS
            end
        end;
      { Our Last Command: query FAX capabilties of the Modem}
      tsATFCLASS :
        begin
          LogMsg('State: tsATFCLASS. Sending AT+FCLASS=?'); //Log
          TrailState := tsWaitForATFCLASS; //Next State, prior to the comport action!!!
          SetTimeOut(1); //Wait 1 Sec
          SerialPortNG1.SendString('AT+FCLASS=?'+#$0d); //Write command
          Done := True; //Leave
        end;
      { Our last response }
      tsWaitForATFCLASS :
        begin
          LogMsg('State: tsWaitForATFCLASS. Received "'+Msg+'"');
          StopTimeOut;
          Done := False;
          TrailState := tsPrepStop; //Nextstep prepare to stop
        end;
      { Error State: No port could be opened}
      tsErrNoPort :
        begin
          LogMsg('State: tsErrNoPort. The Port could not opened');
          TrailState := tsFinal;
        end;
      { Error State: Depending from the Error You may implement Error recovery here}
      tsErrCheck :
        begin
          LogMsg('State: tsErrCheck. Check for recoverable Errors');
          StopTimeOut;
          TrailState := tsPrepStop;
          Done := False;
        end;
      { Error State: We waited for an OK after AT, but...}
      tsErrATOK :
        begin
          LogMsg('State: tsATOKErr. No OK after AT: Stop');
          TrailState := tsPrepStop;
          Done := False;
        end;
      { Error State: We waited for a response but nothing, if You have a
        removable Modem try attach it now}
      tsErrTimeOut :
        begin
          Done := False;
          LogMsg('State: tsErrTimeOut. No Response');
          if LastTrailState = tsWaitForATOK then
            begin
              if RetryCtr > 0 then
                begin
                  LogMsg('Attach Your Modem now,  '+IntToStr(RetryCtr));
                  Dec(RetryCtr);
                  TrailState := tsAT;
                end
              else
                TrailState := tsPrepStop;
            end
          else
            TrailState := tsPrepStop;
        end;
      { Prepare to Stop, will close the Port, and cleanups (if any)}
      tsPrepStop :
        begin
          LogMsg('State: tsPrepStop. Closing Port');
          StopTimeOut;
          TrailState := tsFinal;
          SerialPortNG1.Active := False;
          Done := False;
        end;
      { Finaly we have to enable the buttons, and have to set the state to Idle}
      tsFinal :
        begin
          LogMsg('State: tsFinal. Buttons enabled');
          Done := True; //Finish Trail
          btnStop.Enabled := False;
          btnStart.Enabled := True;
          TrailState := tsIdle;
        end;
    else
    { Another Trap for perfect Programmers, defined events, with no action}
      LogMsg('STOP: Undefined TrailState "'+IntToStr(TrailState)+'"');
      TrailState := tsFinal;
    end;
  until Done; //Loop around
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  GetPortList(cbPorts.Items);       //Collect available Ports
  cbPorts.Items.Add('ComError');     //Add an Port that make trouble
  if cbPorts.Items.Count > 0 then
    cbPorts.ItemIndex := 0;         //Select the first entry
end;

procedure TForm1.btnStartClick(Sender: TObject);
begin
  { If You click on the Go button, You will Start the trail
    this will work only in the State Idle.
    Since this Buttons is disable during run, You can not test this }
  WorkTrail(msStartBtn,'Start Trail');
end;

procedure TForm1.btnStopClick(Sender: TObject);
begin
  { If You click on the Stop Button, You will stop the trail
    this will work in any State.
    Since this Buttons is disabled in Idly, You can not test this }
  WorkTrail(msStopBtn,'Start Trail');
end;

procedure TForm1.SerialPortNG1RxClusterEvent(Sender: TObject);
var Error : Boolean;
    s : String;
begin
  { If the device on the Commport sends something, we will
    receive it here }
  Error := False;
  if SerialPortNG1.NextClusterSize >= 0 then
    begin
      if SerialPortNG1.NextClusterCCError <> 0 then
        Error := True;
      { You musat read the cluster even if an error ocoured }
      s := SerialPortNG1.ReadNextClusterAsString;
    end
  else
    Error := True;
  if Error then
    WorkTrail(msError,'Receiver Error') //Cluster Size is 0, oder Comunication Error
  else
    WorkTrail(msReceiver,s); //Move the Data into the Trail
end;

procedure TForm1.SerialPortNG1WriteDone(Sender: TObject);
begin
  { Write Done
    Unimplemented for now.
    If You have to send large amounts of Data that will not fit into one
    Windows Commport Message Queue (> 3KByte) You have to split the Data
    and send each packet after each other. If one package has been send
    You will find Yourself back here.
    See also the SendFileDemo.
  }
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
  { TimeOut generation }
  if TimerCountDown > 0 then
  { Work only if the Value is > 0}
    begin
      Dec(TimerCountDown); // Reduce by one
      if TimerCountDown = 0 then //If zero generate the Timout
        WorkTrail(msTimeOut,'TimeOut')
    end;
end;

procedure TForm1.SerialPortNG1ProcessError(Sender: TObject; Place,
  Code: Cardinal; Msg: String; Noise: Byte);
begin
  { Error generation from the SerialNG Component
    This can be recursively lead into the WorkTrail procedure!!
  }
  if Noise = enError then
    WorkTrail(msError,Msg)
end;

procedure TForm1.btnCrashClick(Sender: TObject);
begin
  { Chrash the WorkTrail by closing the Port }
  SerialPortNG1.Active := False;
end;

end.
