program SerialNGBasicDemo;

uses
  Forms,
  SerialNGBasic in 'SerialNGBasic.pas' {SerialNGBasicDLG},
  SerialNGStressMain in 'SerialNGStressMain.pas' {Form1};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'SerialNG Basic Demo';
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TSerialNGBasicDLG, SerialNGBasicDLG);
  Application.Run;
end.
