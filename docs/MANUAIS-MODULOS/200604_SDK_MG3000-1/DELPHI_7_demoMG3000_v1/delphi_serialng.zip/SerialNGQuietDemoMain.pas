unit SerialNGQuietDemoMain;
// DomIS Internet Solutions http://www.domis.de
// Visit SerialNG Homepage http://www.domis.de/serialng.htm
{ This Demo shows the behaviour of the SerialPortNG Class in QuietMode
  In this Mode the Thread will not fire any Event to inform You when
  Data is received.
  You must Poll the states by Yourself.
  In some Situations this will makes life very easy, as this Example shows.
  If You have a Modem attached, the Programm will send consequent Modemcommands
  to the Modem (AT, ATI1 to ATI8 and AT+FCLASS=?) and shows the response.
  If You dont have a Modem You may simply shorten Pins 2 and 3 of Your serial
  Port for a Loopback.
  Select a CommPort under Settings and the Press GO
  The Programm stops during the communication, showing the Wait Cursor,
  until all Steps are done. Since all Steps are done into one Procedure ModemComm
  the understanding is very simple.
  Anyway, this example is *not* made for a good communication example.
  QuietMode should used *only* if a reentry with messages should avoided
}
interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  SerialNG, SerialNGBasic, StdCtrls, ComCtrls;

type
  TForm1 = class(TForm)
    SerialPortNG1: TSerialPortNG;
    btnGo: TButton;
    pbProgress: TProgressBar;
    memoResult: TMemo;
    btnSettings: TButton;
    procedure btnSettingsClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnGoClick(Sender: TObject);
  private
    { Private-Deklarationen}
    procedure ModemComm;
  public
    { Public-Deklarationen}
  end;

var
  Form1: TForm1;

implementation

{$R *.DFM}

procedure TForm1.btnSettingsClick(Sender: TObject);
begin
  SerialNGBasicDLG.SetDLGData(SerialPortNG1);
  if SerialNGBasicDLG.ShowModal = mrOK then
    SerialNGBasicDLG.GetDLGData(SerialPortNG1);
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  SerialPortNG1.ThreadQuietMode := True;
end;

procedure TForm1.btnGoClick(Sender: TObject);
var OldCursor : TCursor;
begin
  OldCursor := Screen.Cursor;
  Screen.Cursor := crHourGlass;
  btnGo.Enabled := False;
  try
    pbProgress.Position := 0;
    pbProgress.Max := 10;
    ModemComm;
  finally
    btnGo.Enabled := True;
    Screen.Cursor := OldCursor;
  end;
end;

procedure TForm1.ModemComm;
  function WaitForAnswer(TimeOutSec10 : Integer) : Integer;
  // Checks for Answer and TimeOut -1 = TimeOut
  // TimeOutSec10  Tenth of Seconds to wait (e.g. 100 = 10Seconds)
  begin
    repeat
      Dec(TimeOutSec10);
      Sleep(100);
    until (SerialPortNG1.NextClusterSize >= 0) or (TimeOutSec10 < 0);
    Result := TimeOutSec10;
  end;
var i : Integer;
begin
  SerialPortNG1.Active := True;
  if not SerialPortNG1.Active then
    begin
      memoResult.Lines.Add('Error: Port could not be opened');
      Exit;
    end;
  SerialPortNG1.SendString('AT'+#$0d);
  if WaitForAnswer(100) < 0 then
    begin
      memoResult.Lines.Add('Error: No Answer on AT');
      Exit;
    end;
  pbProgress.StepIt;
  memoResult.Lines.Add('Answer on AT: '+SerialPortNG1.ReadNextClusterAsString);
  for i := 1 to 8 do
    begin
      SerialPortNG1.SendString('ATI'+IntToStr(i)+#$0d); //Send the command
      if WaitForAnswer(100) < 0 then
        begin
          memoResult.Lines.Add('Error: No Answer on ATI'+IntToStr(i));
          Exit;
        end;
      pbProgress.StepIt;
      memoResult.Lines.Add('Answer on ATI'+IntToStr(i)+': '+SerialPortNG1.ReadNextClusterAsString);
    end;
  SerialPortNG1.SendString('AT+FCLASS=?'+#$0d);
  if WaitForAnswer(100) < 0 then
    begin
      memoResult.Lines.Add('Error: No Answer on AT+FCLASS');
      Exit;
    end;
  pbProgress.StepIt;
  memoResult.Lines.Add('Answer on AT+FCLASS=?: '+SerialPortNG1.ReadNextClusterAsString);
end;

end.
