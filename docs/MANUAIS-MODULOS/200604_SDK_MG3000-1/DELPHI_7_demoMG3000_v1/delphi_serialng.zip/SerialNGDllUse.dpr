program SerialNGDllUse;

uses
  Forms,
  SerialNGDllUseMain in 'SerialNGDllUseMain.pas' {Form1},
  SerialNGDllImport in 'SerialNGDllImport.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
