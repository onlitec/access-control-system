program SerialNGStateMachineDemo;

uses
  Forms,
  SerialNGStateMachineDemoMain in 'SerialNGStateMachineDemoMain.pas' {Form1},
  CommPortList in 'CommPortList.pas';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
