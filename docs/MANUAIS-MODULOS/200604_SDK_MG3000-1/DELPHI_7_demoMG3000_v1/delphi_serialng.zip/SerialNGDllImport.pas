unit SerialNGDllImport;
{
  This is the interface to the DLL.
  To avoid very hard to find errors all functions are declared with
  "cdecl" calling convention. This allows other languages (like c) to call
  the dll.
  Please notice that no functions for setting port parms are implemented.
}
interface
// Declaration of functions
  function InitDll : Integer; cdecl; external 'SerialNGDll';
  procedure DoneDll; cdecl; external 'SerialNGDll';
  function OpenPort(PortName : PChar) : Integer; cdecl; external 'SerialNGDll';
  function ClosePort : Integer; cdecl; external 'SerialNGDll';
  function ReadPort(var Buffer; BufferLen : Integer; var RequiredBufferLen : Integer) : Integer; cdecl; external 'SerialNGDll';
  function WritePort(var Buffer; BufferLen : Integer) : Integer; cdecl; external 'SerialNGDll';

implementation

end.
