program SerialNGSFileDemo;

uses
  Forms,
  SerialNGSFileDemoMain in 'SerialNGSFileDemoMain.pas' {Form1},
  SerialNGBasic in 'SerialNGBasic.pas' {SerialNGBasicDLG};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'SerialNG Basic Demo';
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TSerialNGBasicDLG, SerialNGBasicDLG);
  Application.Run;
end.
