program SerialNGRFileDemo;

uses
  Forms,
  SerialNGRFileDemoMain in 'SerialNGRFileDemoMain.pas' {Form1},
  SerialNGBasic in 'SerialNGBasic.pas' {SerialNGBasicDLG};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'SerialNG Basic Demo';
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TSerialNGBasicDLG, SerialNGBasicDLG);
  Application.Run;
end.
