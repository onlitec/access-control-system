unit SerialNGDLG;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls, 
  Buttons, ExtCtrls;

type
  TSerialNGBasicDLG = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    Bevel1: TBevel;
    Button1: TButton;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  SerialNGBasicDLG: TSerialNGBasicDLG;

implementation

{$R *.DFM}
end.
